var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.UseRouting();

app.UseEndpoints(endpoints =>
{
    endpoints.Map("/t1", () => { return "This is T1"; });
    endpoints.Map("/t2", context => { return context.Response.WriteAsync("This is T2"); });
});

app.Map("/t1", () => { return "This is T1"; });
app.Map("/t2", context => { return context.Response.WriteAsync("This is T2"); });

app.Run();
